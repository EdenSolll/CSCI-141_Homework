import immutable_extra as extra
import node_types as node

def convert_to_nodes(dna: str) -> None | node.FrozenNode:
    if dna == "":
        return None
    else:
        return node.FrozenNode(dna[0], convert_to_nodes((dna[1:])))

def main():
    convert_to_nodes("AGT")

if __name__ == "__main__":
    main()
